﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SBMS.Model
{
    class SalesDetial
    {
        public int Sales_DID { get; set; }
        public int Sales_MID { get; set; }
        public int CategoriesID { get; set; }
        public int ProductId { get; set; }
        public int Quantity { get; set; }
        public float MRP { get; set; }
        public float TotalMRP { get; set; }
        



    }
}

 